namespace ConsoleApp1
{
    public interface IObjectProxy
    {
        IObject Object { get; set; }
    }
}